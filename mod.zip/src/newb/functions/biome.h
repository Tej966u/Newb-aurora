#ifndef BIOME_H
#define BIOME_H

#include "detection.h"
#include "utils.h"

// biome weights [0.0, 1.0]
struct nl_biome {
  float desert;
  float swamp;
  float birch;
  float pale;
  float deep;
};

float nlBiomeMatch(vec3 n, vec3 sig) {
  return 1.0 - smoothstep(0.06, 0.28, length(n - sig));
}

// Biomes are tagged with unnatural fog colours in assets/fogs.
// Only the colour ratio is compared so day/night brightness does not matter.
nl_biome nlDetectBiome(vec3 FOG_COLOR, bool ignore) {
  nl_biome b;
  b.desert = 0.0;
  b.swamp = 0.0;
  b.birch = 0.0;
  b.pale = 0.0;
  b.deep = 0.0;
  #ifdef NL_BIOME_FX
    float m = max(FOG_COLOR.r, max(FOG_COLOR.g, FOG_COLOR.b));
    if (!ignore && m > 0.03) {
      vec3 n = FOG_COLOR / m;
      b.desert = nlBiomeMatch(n, NL_BIOME_SIG_DESERT);
      b.swamp = nlBiomeMatch(n, NL_BIOME_SIG_SWAMP);
      b.birch = nlBiomeMatch(n, NL_BIOME_SIG_BIRCH);
      b.pale = nlBiomeMatch(n, NL_BIOME_SIG_PALE);
      b.deep = nlBiomeMatch(n, NL_BIOME_SIG_DEEP);
    }
  #endif
  return b;
}

// fog colour and thickness per biome
void nlBiomeFog(inout vec4 fog, nl_biome b, float relativeDist, float rain) {
  float luma = dot(fog.rgb, vec3(0.299, 0.587, 0.114));
  float d = clamp(relativeDist, 0.0, 1.0);

  // desert: warm sandy dust in the air
  fog.rgb = mix(fog.rgb, vec3(1.0,0.68,0.36)*luma*1.3, clamp(0.45*NL_DESERT_HAZE*b.desert, 0.0, 1.0));
  fog.a += (1.0-fog.a)*0.25*NL_DESERT_HAZE*b.desert*sqrt(d);

  // swamp: thick greenish mist
  fog.rgb = mix(fog.rgb, vec3(0.62,0.85,0.66)*luma, 0.6*b.swamp);
  fog.a += (1.0-fog.a)*NL_SWAMP_MIST*b.swamp*clamp(d*2.5, 0.0, 1.0);

  // birch: clear bright air
  fog.a *= 1.0 - 0.35*clamp(NL_BIRCH_SUN, 0.0, 1.0)*b.birch*(1.0-rain);

  // pale garden: white-out fog
  vec3 paleCol = vec3(0.86,0.88,0.92)*clamp(luma*1.1, 0.25, 1.4);
  fog.rgb = mix(fog.rgb, paleCol, 0.9*b.pale);
  fog.a += (1.0-fog.a)*NL_PALE_FOG*b.pale*smoothstep(0.0, NL_PALE_FOG_RANGE, d);

  // deep dark: dark cold fog closing in
  fog.rgb = mix(fog.rgb, vec3(0.01,0.025,0.035), 0.8*NL_DEEPDARK_DARKEN*b.deep);
  fog.a += (1.0-fog.a)*0.35*NL_DEEPDARK_DARKEN*b.deep*clamp(d*2.0, 0.0, 1.0);
}

// block/entity lighting hue per biome
vec3 nlBiomeLight(vec3 light, nl_biome b, float dayFactor, float rain) {
  float sun = max(dayFactor, 0.0)*(1.0-rain);
  vec3 birch = vec3(1.0,1.0,1.0) + NL_BIRCH_SUN*vec3(0.40,0.36,0.18)*sun;
  light *= mix(vec3(1.0,1.0,1.0), birch, b.birch);
  light *= mix(vec3(1.0,1.0,1.0), vec3(1.08,0.97,0.80), b.desert);
  light *= mix(vec3(1.0,1.0,1.0), vec3(0.88,0.98,0.88), b.swamp);
  light *= mix(vec3(1.0,1.0,1.0), vec3(0.92,0.95,1.0), b.pale);
  light *= mix(vec3(1.0,1.0,1.0), vec3(0.55,0.65,0.80), NL_DEEPDARK_DARKEN*b.deep);
  return light;
}

// sky tint per biome
vec3 nlBiomeSky(vec3 sky, nl_biome b) {
  float luma = dot(sky, vec3(0.299, 0.587, 0.114));
  sky *= mix(vec3(1.0,1.0,1.0), vec3(1.12,0.98,0.78), 0.8*clamp(NL_DESERT_HAZE, 0.0, 1.0)*b.desert);
  sky = mix(sky, vec3(0.7,0.92,0.75)*luma, 0.5*b.swamp);
  sky *= mix(vec3(1.0,1.0,1.0), vec3(0.97,1.03,1.12), b.birch);
  sky = mix(sky, vec3(0.82,0.85,0.9)*clamp(luma, 0.2, 1.5), 0.85*b.pale);
  sky *= 1.0 - 0.75*NL_DEEPDARK_DARKEN*b.deep;
  return sky;
}

#endif
