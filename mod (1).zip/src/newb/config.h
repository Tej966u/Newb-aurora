#ifndef NL_CONFIG_H
#define NL_CONFIG_H

/*
  NEWB SHADER MAIN CONFIG
  This part contains base configuration options for the shader.

  TOGGLES
  - If [toggle] is mentioned, then
    options can be commented to disable (by adding '//')
  - eg: #define PLANTS_WAVE    -> this is ON
        //#define PLANTS_WAVE  -> this is OFF

  COLOR VALUES
  - Color format: vec3(red,green,blue)
  - 1.0 means 100%, 0.0 means 0%
  - eg: vec3(1.0,1.0,0.0) = yellow

  VALUES
  - Values must be decimal
  - eg. 32 is wrong, 32.0 is correct

  TYPES
  - Should be integer. options to choose will be mentioned there
  - eg: #define NL_CLOUD_TYPE 2

  Remember to rebuild the shader after making changes.
*/

/* Color correction */
#define NL_TONEMAP_TYPE 3              // 1:Exponential, 2:Reinhard, 3:Extended Reinhard, 4:ACES
#define NL_GAMMA 1.33                  // 0.3 low ~ 2.0 high
//#define NL_EXPOSURE 1.3              // [toggle] 0.5 dark ~ 3.0 bright
#define NL_SATURATION 1.12             // [toggle] 0.0 grayscale ~ 4.0 super saturated
//#define NL_TINT                      // [toggle] enable light/dark tone tinting
#define NL_TINT_LOW  vec3(0.3,0.5,1.4) // color tint for dark tone
#define NL_TINT_HIGH vec3(1.4,0.7,0.3) // color tint for light tone

/* Lighting */
#define NL_SUNLIGHT_INTENSITY   3.3  // 1.0 weak ~ 5.0 bright
#define NL_TORCHLIGHT_INTENSITY 1.0  // 0.5 weak ~ 3.0 bright
#define NL_SHADOW_INTENSITY     0.7  // 0.0 no shadow ~ 1.0 strong shadow
#define NL_MIN_LIGHTING_BOOST   1.5  // 1.0 minimal lighting boost for dark areas ~ 3.0 brighter dark areas
//#define NL_BLINKING_TORCH  // [toggle] flickering light
#define NL_CLOUD_SHADOW      // [toggle] cloud shadow (simple clouds only)

/* Ambient light for nether/end */
#define NL_NETHER_AMBIENT vec3(3.0,2.16,1.89)
#define NL_END_AMBIENT    vec3(1.98,1.25,2.3)

/* Sun/moon light color */
#define NL_DAWN_SUNLIGHT_COL   vec3(1.0,0.4,0.1)
#define NL_NOON_SUNLIGHT_COL   vec3(1.0,0.75,0.57)
#define NL_NIGHT_MOONLIGHT_COL vec3(0.01,0.03,0.2)

/* Torch colors */
#define NL_OVERWORLD_TORCH_COL  vec3(1.0,0.52,0.18)
#define NL_UNDERWATER_TORCH_COL vec3(1.0,0.52,0.18)
#define NL_NETHER_TORCH_COL     vec3(1.0,0.52,0.18)
#define NL_END_TORCH_COL        vec3(1.0,0.52,0.18)

/* Fog */
#define NL_FOG 1.0                // [toggle] 0.1 subtle ~ 1.0 blend with sky completely
#define NL_MIST_DENSITY 0.18      // 0.0 no mist ~ 1.0 misty
#define NL_RAIN_MIST_OPACITY 0.12 // [toggle] 0.04 very subtle ~ 0.5 thick rain mist blow
#define NL_CLOUDY_FOG 0.1         // [toggle] 0.0 subtle - 0.8 dense fog clouds

/* Sky */
#define NL_SKY_VOID_FACTOR     0.5
#define NL_SKY_VOID_DARKNESS   0.3
#define NL_SKY_RAIN_MIX_FACTOR 0.9

/* Sky colors - zenith=top, horizon=bottom */
#define NL_DAWN_ZENITH_COL   vec3(0.1,0.4,0.7)
#define NL_DAWN_HORIZON_COL  vec3(3.0,0.4,0.4)
#define NL_DAWN_EDGE_COL     vec3(2.0,0.8,0.8)
#define NL_DAY_ZENITH_COL    vec3(0.3,0.9,2.0)
#define NL_DAY_HORIZON_COL   vec3(1.0,1.6,1.8)
#define NL_DAY_EDGE_COL      vec3(1.44,1.56,1.62)
#define NL_NIGHT_ZENITH_COL  vec3(0.008,0.048,0.08)
#define NL_NIGHT_HORIZON_COL vec3(0.02,0.06,0.1)
#define NL_NIGHT_EDGE_COL    vec3(0.04,0.08,0.1)
#define NL_RAIN_ZENITH_COL   vec3(0.47,0.51,0.56)
#define NL_RAIN_HORIZON_COL  vec3(0.6,0.6,0.6)

#define NL_END_ZENITH_COL    vec3(0.08,0.001,0.1)
#define NL_END_HORIZON_COL   vec3(0.6,0.02,0.6)


/* Rainbow */
#define NL_RAINBOW           // [toggle] enable rainbow in sky
#define NL_RAINBOW_CLEAR 0.0 // 0.3 subtle ~ 1.0 bright during clear weather
#define NL_RAINBOW_RAIN  0.4 // 0.3 subtle ~ 1.0 bright during rain weather

/* Ore glow intensity */
#define NL_GLOW_TEX 2.3           // 0.4 weak ~ 8.0 bright
#define NL_GLOW_SHIMMER 0.8       // [toggle] 0.1 subtle ~ 1.0 100% shimmer
#define NL_GLOW_SHIMMER_SPEED 0.9 // 0.5 slow - 2.0 fast
//#define NL_GLOW_LEAK 0.6        // [toggle] 0.08 subtle ~ 1.0 100% brightness of NL_GLOW_TEX

/* Rain / storm ambience */
#define NL_RAIN_GLOOM 0.22         // [toggle] 0.05 subtle ~ 0.5 very gloomy outdoors during rain
#define NL_RAIN_CLARITY 1.5        // [toggle] 1.0 vanilla ~ 3.0 rain streaks more visible
#define NL_RAIN_SPLASH 0.9         // [toggle] 0.2 subtle ~ 2.0 bright flash where rain hits the ground
#define NL_SNOW_DISSOLVE 1.0       // [toggle] 0.0 off ~ 1.0 snow flakes fade out softly near the ground
#define NL_SNOW_DISSOLVE_HEIGHT 2.0 // blocks above ground where snow starts to dissolve

/* Storm effects (only active while raining/thundering) */
#define NL_STORM_WIND 2.2          // 1.0 same as normal ~ 4.0 violent plant/leaf/lantern sway in storms
#define NL_STORM_WATER_BUMP 2.0    // 0.0 none ~ 5.0 very rough water in storms

/* Waving */
#define NL_PLANTS_WAVE 0.05    // [toggle] 0.02 gentle ~ 0.4 violent
#define NL_LANTERN_WAVE 0.16   // [toggle] 0.05 subtle ~ 0.4 large swing
#define NL_WAVE_SPEED 2.8      // 0.5 slow wave ~ 5.0 very fast wave
//#define NL_EXTRA_PLANTS_WAVE // [toggle] !dont use! wave using texture coords (1.21.0 vanilla 2048x1024)
#define NL_WAVE_RANGE 10.0     // 6.0 upto 6 blocks ~ 32.0 upto 32 blocks away (slower)

/* Water */
#define NL_WATER_TRANSPARENCY 0.9 // 0.0 transparent ~ 1.0 normal
#define NL_WATER_BUMP 0.09        // 0.001 plain ~ 0.2 bumpy water
#define NL_WATER_WAVE_SPEED  0.8  // 0.2 calm ~ 2.0 turbulent
#define NL_WATER_TEX_OPACITY 0.3  // 0.0 plain water ~ 1.0 vanilla water texture
#define NL_WATER_WAVE             // [toggle] wave effect
//#define NL_WATER_REFL_MASK      // [toggle] fake water reflection mask
#define NL_WATER_TINT vec3(0.52,0.9,0.45)

/* Underwater */
#define NL_UNDERWATER_BRIGHTNESS 0.8         // 0.0 dark ~ 3.0 bright
#define NL_CAUSTIC_INTENSITY 1.9             // 0.5 weak ~ 5.0 bright
#define NL_UNDERWATER_WAVE 0.1               // [toggle] 0.02 subtle ~ 0.6 trippy
#define NL_UNDERWATER_STREAKS 1.0            // [toggle] 0.8 subtle - 2.0 bright streaks from top
#define NL_UNDERWATER_TINT vec3(0.9,1.0,0.9) // fog tint color when underwater

/* Cloud type */
#define NL_CLOUD_TYPE 1 // 0:vanilla, 1:soft, 2:rounded, 3:realistic

/* Vanilla cloud settings - make sure to remove clouds.png when using this */
#define NL_CLOUD0_THICKNESS 2.1      // 0.5 slim ~ 8.0 fat
#define NL_CLOUD0_RAIN_THICKNESS 4.0 // 0.5 slim ~ 8.0 fat
#define NL_CLOUD0_OPACITY 0.9        // 0.0 invisible ~ 1.0 opaque
//#define NL_CLOUD0_MULTILAYER       // [toggle] extra cloud layer (costs performance)

/* Soft cloud settings */
#define NL_CLOUD1_SCALE vec2(0.016, 0.022) // 0.003 large ~ 0.2 tiny
#define NL_CLOUD1_DEPTH 1.3                // 0.0 no bump ~ 10.0 large bumps
#define NL_CLOUD1_SPEED 0.04               // 0.0 static ~ 0.4 fast moving
#define NL_CLOUD1_DENSITY 0.54             // 0.1 less clouds ~ 0.8 more clouds
#define NL_CLOUD1_OPACITY 0.9              // 0.0 invisible ~ 1.0 opaque

/* Rounded cloud settings */
#define NL_CLOUD2_THICKNESS 2.1            // 0.5 slim ~ 5.0 fat
#define NL_CLOUD2_RAIN_THICKNESS 2.5       // 0.5 slim ~ 5.0 fat
#define NL_CLOUD2_STEPS 5                  // 3 low quality ~ 16 high quality
#define NL_CLOUD2_SCALE vec2(0.033, 0.033) // 0.003 large ~ 0.3 tiny
#define NL_CLOUD2_SHAPE vec2(0.5, 0.4)     // 0.0 round ~ 1.0 box vec2(horizontal shape, vertical shape)
#define NL_CLOUD2_DENSITY 25.0             // 1.0 blurry ~ 100.0 sharp
#define NL_CLOUD2_VELOCITY 0.8             // 0.0 static ~ 4.0 very fast
//#define NL_CLOUD2_LAYER2                      // [toggle] extra cloud layer
#define NL_CLOUD2_LAYER2_OFFSET 143.0           // 30.0 near ~ 300.0 very high
#define NL_CLOUD2_LAYER2_THICKNESS 2.5          // 0.7 slim ~ 5.0 fat
#define NL_CLOUD2_LAYER2_RAIN_THICKNESS 3.0     // 0.7 slim ~ 5.0 fat
#define NL_CLOUD2_LAYER2_STEPS 3                // 3 low quality ~ 16 high quality
#define NL_CLOUD2_LAYER2_SCALE vec2(0.03, 0.03) // 0.003 large ~ 0.3 tiny
#define NL_CLOUD2_LAYER2_SHAPE vec2(0.5, 0.4)   // 0.0 round ~ 1.0 box vec2(horizontal shape, vertical shape)
#define NL_CLOUD2_LAYER2_DENSITY 25.0           // 1.0 blurry ~ 100.0 sharp
#define NL_CLOUD2_LAYER2_VELOCITY 0.8           // 0.0 static ~ 4.0 very fast

/* Realistic cloud settings */
#define NL_CLOUD3_SCALE vec2(0.03, 0.03) // 0.003 large ~ 1.0 tiny
#define NL_CLOUD3_SPEED 0.005            // 0.0 static ~ 4.0 fast moving
#define NL_CLOUD3_SHADOW 0.9             // 0.1 subtle ~ 1.0 dark
#define NL_CLOUD3_SHADOW_OFFSET 0.3      // 0.05 minimal ~ 1.0 large

/* Aurora settings */
#define NL_AURORA 1.8           // [toggle] 0.4 dim ~ 4.0 very bright
#define NL_AURORA_VELOCITY 0.04 // 0.0 static ~ 0.3 very fast
#define NL_AURORA_SCALE 0.04    // 0.002 large ~ 0.4 tiny
#define NL_AURORA_WIDTH 0.22    // 0.04 thin line ~ 0.4 thick lines
#define NL_AURORA_COL1 vec3(0.1,1.0,0.3)  // green
#define NL_AURORA_COL2 vec3(0.3,0.1,1.0)  // violet
#define NL_AURORA_COL3 vec3(0.0,0.9,0.9)  // teal highlights
#define NL_AURORA_COL4 vec3(1.0,0.25,0.6) // crimson-pink fringe on curtain tops
#define NL_AURORA_SHIMMER 0.25  // [toggle] 0.1 subtle ~ 0.5 strong moving ray shimmer
#define NL_AURORA_LAYER2        // [toggle] second drifting curtain for a richer aurora (costs performance)
#define NL_AURORA_GLOW 0.18     // [toggle] 0.05 subtle ~ 0.5 night ground lit by aurora colours

#define NL_CLOUD_AURORA_REFLECTION // [toggle] simple clouds/aurora reflection

/* Shooting star */
#define NL_SHOOTING_STAR 1.0        // [toggle] 0.2 dim ~ 1.0 bright
#define NL_SHOOTING_STAR_PERIOD 6.0 // 0.4 fast ~ 12.0 slow (12 secs)
#define NL_SHOOTING_STAR_DELAY 64.0 // 0.0 no delay ~ 100.0 long time (100 secs)

/* Galaxy */
//#define NL_GALAXY_STARS 2.0           // [toggle] 0.1 dim - 4.0 bright
#define NL_GALAXY_VIBRANCE 0.7          // 0.0 white - 1.0 colorful
#define NL_GALAXY_SPEED 0.03            // 0.01 slow motion - 0.2 fast motion
#define NL_GALAXY_DAY_VISIBILITY 0.0    // 0.0 invisible - 1.0 visible

/* Chunk loading slide in animation */
//#define NL_CHUNK_LOAD_ANIM 100.0 // [toggle] -600.0 fall from top ~ 600.0 rise from bottom

/* Other dimensions */
#define NL_NETHER_EMBER 1.0 // [toggle] 0.3 subtle ~ 2.0 warm ember haze in the Nether
#define NL_END_VOID 1.0     // [toggle] 0.3 subtle ~ 2.0 deeper purple void haze in the End

/* End planet: a Saturn-inspired ringed planet in the End sky */
#define NL_END_PLANET                           // [toggle] planet in the End sky
#define NL_END_PLANET_RING                      // [toggle] 3D ring with shadows
#define NL_END_PLANET_MOON                      // [toggle] small moon
#define NL_END_PLANET_SIZE 16.0                 // 6.0 small ~ 30.0 huge (angular radius in degrees)
#define NL_END_PLANET_DIR vec3(0.55,0.42,0.72)  // direction in the sky (x, y up, z). Raise y to move it higher
#define NL_END_PLANET_AXIS vec3(0.25,0.86,0.45) // pole/ring tilt (x right, y up, z towards you). Bigger z = seen more from above
#define NL_END_PLANET_LIGHT vec3(-0.80,0.30,0.52) // where the light comes from (x right, y up, z towards you)
#define NL_END_PLANET_COL1 vec3(0.95,0.80,0.55)  // light bands (cream gold)
#define NL_END_PLANET_COL2 vec3(0.55,0.36,0.26)  // dark bands (amber)
#define NL_END_PLANET_COL3 vec3(1.00,0.88,0.80)  // bright highlights
#define NL_END_PLANET_POLAR_COL vec3(0.18,0.32,0.45) // polar hexagon
#define NL_END_PLANET_RING_COL vec3(0.85,0.74,0.62)  // ring colour
#define NL_END_PLANET_ATMOS vec3(1.0,0.85,0.60)  // atmosphere colour
#define NL_END_PLANET_GLOW 0.5                   // 0.0 no atmosphere ~ 1.5 strong
// Other palettes: Neptune COL1 vec3(0.35,0.55,1.0) COL2 vec3(0.10,0.20,0.65) ATMOS vec3(0.4,0.6,1.0)
//                 Jupiter COL1 vec3(0.90,0.75,0.60) COL2 vec3(0.55,0.30,0.20)

/* Quality of life */
#define NL_TEXTURE_CONTRAST 0.35 // [toggle] 0.1 subtle ~ 1.0 strong colour contrast so block textures pop
#define NL_TEXTURE_BUMP 0.6      // [toggle] 0.2 subtle ~ 1.5 strong fake depth: texture pixels get a light/dark edge
#define NL_TWILIGHT_MIST 0.5 // [toggle] 0.1 subtle ~ 1.5 golden mist at sunrise and sunset

/* Light source warmth */
#define NL_TORCH_GLOW 0.30  // [toggle] 0.1 subtle ~ 1.0 strong warm light on nearby blocks
#define NL_TORCH_HAZE 0.45  // [toggle] 0.1 subtle ~ 1.5 warm glow in fog around lights

/* Sun/Moon slight sway (degrees) */
#define NL_CELESTIAL_WOBBLE 3.0 // [toggle] 1.0 subtle ~ 8.0 clearly rocking

/* Biome ambience (EXPERIMENTAL)
   Biomes are detected from custom fog colours set in assets/biomes_client.json + assets/fogs.
   If the effects do not show, pick the BIOME_DEBUG subpack to check detection. */
#define NL_BIOME_FX
#define NL_BIOME_SIG_DESERT vec3(1.0,0.102,0.451)
#define NL_BIOME_SIG_SWAMP  vec3(0.102,1.0,0.451)
#define NL_BIOME_SIG_BIRCH  vec3(0.451,1.0,0.102)
#define NL_BIOME_SIG_PALE   vec3(1.0,0.302,0.851)
#define NL_BIOME_SIG_DEEP   vec3(0.0,0.6,1.0)
#define NL_DESERT_HAZE 1.0         // 0.0 off ~ 2.0 thick sandy dust in the air
#define NL_SWAMP_MIST 0.55         // 0.0 off ~ 0.9 thick swamp mist
#define NL_BIRCH_SUN 1.0           // 0.0 normal ~ 2.0 blazing sunny birch forests
#define NL_PALE_FOG 0.95           // 0.0 off ~ 1.0 total white-out
#define NL_PALE_FOG_RANGE 0.18     // 0.05 very close fog ~ 0.5 far fog (fraction of render distance)
#define NL_PALE_EYE_GLOW 1.0       // 0.0 off ~ 1.0 glowing mob eyes stay visible in pale garden fog
#define NL_DEEPDARK_DARKEN 0.75    // 0.0 normal ~ 1.0 pitch dark deep dark
#define NL_SNOW_BIOME 1.0          // 0.0 off ~ 2.0 cold crisp air in snowy biomes
#define NL_JUNGLE_HUMID 1.0        // 0.0 off ~ 2.0 humid green haze in jungles
#define NL_BADLANDS_DUST 1.0       // 0.0 off ~ 2.0 red dust in badlands
#define NL_CHERRY_DREAM 1.0        // 0.0 off ~ 2.0 dreamy pink haze in cherry groves
#define NL_MUSHROOM_SPORE 1.0      // 0.0 off ~ 2.0 purple spore haze in mushroom fields
#define NL_BIOME_SIG_SNOW     vec3(0.149,0.851,1.0)
#define NL_BIOME_SIG_JUNGLE   vec3(0.0,1.0,0.0)
#define NL_BIOME_SIG_BADLANDS vec3(1.0,0.0,0.0)
#define NL_BIOME_SIG_CHERRY   vec3(0.6,0.0,1.0)
#define NL_BIOME_SIG_MUSHROOM vec3(1.0,1.0,0.0)

/* Sun/Moon */
#define NL_SUN_SIZE  1.0           // 0.3 tiny ~ 4.0 massive
#define NL_MOON_SIZE 1.0           // 0.3 tiny ~ 4.0 massive
#define NL_SUN_PATH_YAW    15.0 //
#define NL_MOON_PATH_YAW   17.0 //
#define NL_SUN_PATH_TILT   31.0 //
#define NL_MOON_PATH_TILT -28.0 //
#define NL_SUN_TILT        45.0 // 0.0 no tilt ~ 90.0 tilt of 90 degrees
#define NL_MOON_TILT       45.0 // 0.0 no tilt ~ 90.0 tilt of 90 degrees

/* Fake godrays during sunrise/sunset */
//#define NL_GODRAY 0.3 // [toggle] 0.1 subtle ~ 0.8 strong

/* Sky reflection */
//#define NL_GROUND_REFL 0.4       // [toggle] 0.2 slightly reflective ~ 1.0 fully reflect sky
#define NL_GROUND_RAIN_WETNESS 1.0 // 0.0 no wetness ~ 1.0 fully wet blocks when raining
#define NL_GROUND_RAIN_PUDDLES 0.7 // 0.0 no puddles ~ 1.0 puddles

/* Entity (Actor, ItemInHand) */
#define NL_ENTITY_BRIGHTNESS     0.65 // 0.1 dark ~ 1.6 bright
#define NL_ENTITY_EDGE_HIGHLIGHT 0.41 // [toggle] 0.0 no highlight ~ 1.6 bright highlight

/* Weather particles */
#define NL_WEATHER_SPECK 0.6         // [toggle] 0.0 vanilla texture ~ 1.0 soft speck
#define NL_WEATHER_RAIN_SLANT 4.0    // 1.0 minimal ~ 8.0 violent
#define NL_WEATHER_PARTICLE_SIZE 1.0 // 0.5 tiny ~ 4.0 large

/* Lava effects */
#define NL_LAVA_NOISE            // [toggle] darken lava in certain regions
//#define NL_LAVA_NOISE_BUMP 0.2 // [toggle] 0.1 subtle ~ 0.8 massive waves
#define NL_LAVA_NOISE_SPEED 0.2  // 0.0 still ~ 0.8 fast

/*
  NEWB SHADER SUBPACK CONFIG
  This part contains custom configuration options for each subpack.

  If a value is already defined,
  then you must undefine it before modifying:
  eg: #undef OPTION_NAME

  Subpack names and flags are inside `pack_config.toml`.
  Build tool will enable corresponding flags when compiling.
*/

#ifdef BIOME_DEBUG
  #define NL_BIOME_DEBUG // tints blocks: red=desert green=swamp yellow=birch white=pale garden blue=deep dark
#endif

#ifdef LITE
  #define NO_WAVE
  #undef NL_GLOW_SHIMMER
  #undef NL_LAVA_NOISE
  #undef NL_WEATHER_SPECK
  #undef NL_SHOOTING_STAR
  #undef NL_CLOUD_AURORA_REFLECTION
  #undef NL_UNDERWATER_STREAKS
  #undef NL_RAIN_MIST_OPACITY
  #undef NL_CLOUDY_FOG
  #undef NL_ENTITY_EDGE_HIGHLIGHT
  #undef NL_TORCH_HAZE
  #undef NL_RAIN_SPLASH
  #undef NL_SNOW_DISSOLVE
  #undef NL_AURORA_SHIMMER
  #undef NL_CLOUD0_MULTILAYER
  #undef NL_TEXTURE_BUMP
  #undef NL_AURORA_LAYER2
  #undef NL_END_PLANET_RING
  #undef NL_END_PLANET_MOON
  #undef NL_RAINBOW
  #undef NL_CLOUD_SHADOW
#endif

#ifdef CINEMATIC
  // everything pretty, for strong phones and screenshots
  #undef NL_AURORA
  #define NL_AURORA 2.6
  #undef NL_AURORA_GLOW
  #define NL_AURORA_GLOW 0.3
  #define NL_GODRAY 0.35
  #define NL_GROUND_REFL 0.5
  #define NL_GALAXY_STARS 2.0
  #undef NL_TEXTURE_BUMP
  #define NL_TEXTURE_BUMP 0.9
  #undef NL_CLOUD_TYPE
  #define NL_CLOUD_TYPE 2
  #undef NL_CLOUD_SHADOW
#endif

#ifdef NO_WAVE_NO_FOG
  #define NO_WAVE
  #define NO_FOG
#endif

#ifdef NO_FOG
  #undef NL_FOG
#endif

#ifdef NO_WAVE
  #undef NL_PLANTS_WAVE
  #undef NL_LANTERN_WAVE
  #undef NL_UNDERWATER_WAVE
  #undef NL_WATER_WAVE
  #undef NL_RAIN_MIST_OPACITY
#endif

#ifdef CHUNK_ANIM
  #define NL_CHUNK_LOAD_ANIM 100.0
#endif

#ifdef ROUNDED_CLOUDS
  #undef NL_CLOUD_TYPE
  #define NL_CLOUD_TYPE 2
  #undef NL_CLOUD_SHADOW // TODO: Cloud shadow for rounded, realistic clouds
#endif

#ifdef BOX_CLOUDS
  #undef NL_CLOUD_TYPE
  #define NL_CLOUD_TYPE 0
  #undef NL_CLOUD_SHADOW
#endif

#ifdef REALISTIC_CLOUDS
  #undef NL_CLOUD_TYPE
  #define NL_CLOUD_TYPE 3
  #undef NL_CLOUD_SHADOW
#endif

#endif
