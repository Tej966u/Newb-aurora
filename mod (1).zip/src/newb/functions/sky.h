#ifndef SKY_H
#define SKY_H

#include "detection.h"
#include "noise.h"

struct nl_skycolor {
  vec3 zenith;
  vec3 horizon;
  vec3 horizonEdge;
};

// rainbow spectrum
vec3 spectrum(float x) {
  vec3 s = vec3(x-0.5, x, x+0.5);
  s = smoothstep(1.0,0.0,abs(s));
  return s*s;
}

vec3 getUnderwaterCol(vec3 FOG_COLOR) {
  return 2.0*NL_UNDERWATER_TINT*FOG_COLOR*FOG_COLOR;
}

vec3 getEndZenithCol() {
  return NL_END_ZENITH_COL;
}

vec3 getEndHorizonCol() {
  return NL_END_HORIZON_COL;
}

nl_skycolor nlEndSkyColors(nl_environment env) {
  nl_skycolor s;
  s.zenith = getEndZenithCol();
  s.horizon = getEndHorizonCol();
  s.horizonEdge = s.horizon;
  return s;
}

nl_skycolor nlOverworldSkyColors(nl_environment env) {
  nl_skycolor s;
  float f = 1.0 + 2.0*(1.0-max(-env.dayFactor, 0.0));
  float nightFactor = step(env.dayFactor, 0.0);
  s.zenith = mix(NL_DAY_ZENITH_COL, NL_NIGHT_ZENITH_COL*f, nightFactor);
  s.horizon = mix(NL_DAY_HORIZON_COL, NL_NIGHT_HORIZON_COL*f, nightFactor);
  s.horizonEdge = mix(NL_DAY_EDGE_COL, NL_NIGHT_EDGE_COL*f, nightFactor);

  float dawnFactor = 1.0-env.dayFactor*env.dayFactor;
  dawnFactor *= dawnFactor*dawnFactor;
  dawnFactor *= mix(1.0, dawnFactor*dawnFactor, nightFactor);
  s.zenith = mix(s.zenith, NL_DAWN_ZENITH_COL, dawnFactor);
  s.horizon = mix(s.horizon, NL_DAWN_HORIZON_COL, dawnFactor);
  s.horizonEdge = mix(s.horizonEdge, NL_DAWN_EDGE_COL, dawnFactor);

  float zh = dot(s.zenith, vec3_splat(0.33));
  float hh = dot(s.horizon, vec3_splat(0.33));
  float rainMix = env.rainFactor*NL_SKY_RAIN_MIX_FACTOR;
  s.zenith = mix(s.zenith, NL_RAIN_ZENITH_COL*zh, rainMix);
  s.horizon = mix(s.horizon, NL_RAIN_HORIZON_COL*hh, rainMix);
  s.horizonEdge = mix(s.horizonEdge, s.horizon, env.rainFactor);

  if (env.underwater) {
    vec3 underwaterFog = env.fogCol*env.fogCol*NL_UNDERWATER_TINT;
    s.zenith = mix(2.0*underwaterFog, underwaterFog*zh, 0.8);
    s.horizon = mix(2.0*underwaterFog, underwaterFog*hh, 0.8);
    s.horizonEdge = s.horizon;
  }

  return s;
}

nl_skycolor nlSkyColors(nl_environment env) {
  if (env.end) {
    return nlEndSkyColors(env);
  }
  return nlOverworldSkyColors(env);
}


vec3 renderOverworldSky(nl_skycolor skyCol, nl_environment env, vec3 viewDir, bool isSkyPlane) {
  float avy = abs(viewDir.y);
  float mask = 0.5 + (0.5*viewDir.y/(0.4 + avy));

  vec2 g = clamp(0.5 - 0.5*vec2(dot(env.sunDir, viewDir), dot(env.moonDir, viewDir)), 0.0, 1.0);
  vec2 g1 = 1.0-mix(sqrt(g), g, env.rainFactor);
  vec2 g2 = g1*g1;
  vec2 g4 = g2*g2;
  vec2 g8 = g4*g4;
  float mg8 = (g8.x+g8.y)*mask*(1.0-0.9*env.rainFactor);

  float vh = 1.0 - viewDir.y*viewDir.y;
  float vh2 = vh*vh;
  vh2 = mix(vh2, mix(1.0, vh2*vh2, NL_SKY_VOID_FACTOR), step(viewDir.y, 0.0));
  vh2 = mix(vh2, 1.0, mg8);
  float vh4 = vh2*vh2;

  float gradient1 = vh4*vh4;
  float gradient2 = 0.8*gradient1 + 0.2*vh2;
  gradient1 *= gradient1;
  gradient1 = mix(gradient1*gradient1, 1.0, mg8);
  gradient2 = mix(gradient2, 1.0, mg8);

  float dawnFactor = 1.0-env.dayFactor*env.dayFactor;
  float df = mix(1.0, g2.x, dawnFactor*dawnFactor);
  vec3 sky = mix(skyCol.horizon, skyCol.horizonEdge, gradient1*df*df);
  sky = mix(skyCol.zenith, sky, gradient2*df);

  sky *= 0.5+0.5*gradient2;
  sky *= (1.0 + (2.0*mg8 + 7.0*mg8*mg8)*mask)*mix(1.0, mask, NL_SKY_VOID_DARKNESS);

  if (!isSkyPlane) {
    float source = max(0.0, (mg8-0.22)/0.78);
    source *= source;
    source *= source;
    sky *= 1.0 + 15.0*source*(1.0-env.rainFactor);
  }

  #ifdef NL_RAINBOW
    if (!env.underwater) {
      float rainbowFade = 0.5 + 0.5*viewDir.y;
      rainbowFade *= rainbowFade;
      rainbowFade *= mix(NL_RAINBOW_CLEAR, NL_RAINBOW_RAIN, env.rainFactor);
      rainbowFade *= 0.5+0.5*env.dayFactor;
      sky += spectrum(24.2*(0.85-g.x))*rainbowFade*skyCol.horizon;
    }
  #endif

  return sky;
}

vec3 renderEndSky(vec3 horizonCol, vec3 zenithCol, vec3 viewDir, float t) {
  t *= 0.1;
  float a = atan2(viewDir.x, viewDir.z);

  float n1 = 0.5 + 0.5*sin(3.0*a + t + 10.0*viewDir.x*viewDir.y);
  float n2 = 0.5 + 0.5*sin(5.0*a + 0.5*t + 5.0*n1 + 0.1*sin(40.0*a -4.0*t));

  float waves = 0.7*n2*n1 + 0.3*n1;

  float grad = 0.5 + 0.5*viewDir.y;
  float streaks = waves*(1.0 - grad*grad*grad);
  streaks += (1.0-streaks)*smoothstep(1.0-waves, -1.0, viewDir.y);

  float f = 0.3*streaks + 0.7*smoothstep(1.0, -0.5, viewDir.y);
  float h = streaks*streaks;
  float g = h*h;
  g *= g;

  vec3 sky = mix(zenithCol, horizonCol, f*f);
  sky += (0.1*streaks + 2.0*g*g*g + h*h*h)*vec3(2.0,0.5,0.0);
  sky += 0.25*streaks*spectrum(sin(2.0*viewDir.x*viewDir.y+t));

  return sky;
}

#ifdef NL_END_PLANET
// density of the planet ring at distance R (in planet radii): C ring, B ring, Cassini division, A ring, Encke gap
float nlRingDensity(float R) {
  float c = 0.25*smoothstep(1.24, 1.32, R)*(1.0 - smoothstep(1.48, 1.53, R));
  float b = 0.95*smoothstep(1.50, 1.56, R)*(1.0 - smoothstep(1.93, 1.97, R));
  float a = 0.70*smoothstep(2.02, 2.06, R)*(1.0 - smoothstep(2.25, 2.28, R));
  a *= 1.0 - 0.85*(1.0 - smoothstep(0.0, 0.012, abs(R - 2.20)));
  float d = max(max(c, b), a);
  float ripple = 0.82 + 0.18*sin(R*70.0)*sin(R*29.0 + 1.0);
  return d*ripple;
}

// Saturn-inspired planet in the End sky (fixed in the skybox, so it drifts slowly with the stars).
// Works in a view frame: x right, y up, z towards the viewer. The planet has a real 3D ring
// (ring shadow on the planet, planet shadow on the ring), limb darkening, banded turbulence,
// a polar hexagon and a small moon.
vec3 nlRenderEndPlanet(vec3 sky, vec3 viewDir, float t) {
  vec3 pd = normalize(NL_END_PLANET_DIR);
  if (dot(viewDir, pd) < 0.0) {
    return sky;
  }

  vec3 pr = normalize(cross(vec3(0.0,1.0,0.0), pd));
  vec3 pu = cross(pd, pr);
  float radius = NL_END_PLANET_SIZE*0.0174533;
  vec2 p = vec2(dot(viewDir, pr), dot(viewDir, pu))/radius;
  float r2 = dot(p, p);
  if (r2 > 7.0) {
    return sky;
  }
  float r = sqrt(r2);

  vec3 axis = normalize(NL_END_PLANET_AXIS);    // planet north pole and ring normal
  vec3 L = normalize(NL_END_PLANET_LIGHT);      // direction towards the light

  // ---- planet sphere
  float disc = 1.0 - smoothstep(0.985, 1.0, r);
  float zs = sqrt(max(1.0 - r2, 0.0));
  vec3 n = vec3(p.x, p.y, zs);
  float lit = dot(n, L);
  float lat = dot(n, axis);

  vec3 e1 = normalize(cross(axis, vec3(1.0,0.0,0.0)));
  vec3 e2 = cross(axis, e1);
  float spin = 0.01*t; // slow visible rotation
  float u0 = dot(n, e1);
  float v0 = dot(n, e2);
  vec2 uv = vec2(cos(spin)*u0 - sin(spin)*v0, sin(spin)*u0 + cos(spin)*v0);
  float eddy = 0.3*sin(0.05*t); // bounded drift so bands slowly churn without smearing

  // banded turbulence
  float n1 = noise2D(vec2(uv.x*2.5 + lat*1.3 + eddy, lat*10.0));
  float n2 = noise2D(vec2(uv.y*5.0 - lat*2.0 - eddy, lat*22.0 + 3.0));
  float n3 = noise2D(vec2(uv.x*9.0 + uv.y*4.0, lat*40.0));
  float n4 = noise2D(vec2(uv.x*18.0 + lat*3.0 + 2.0*eddy, lat*70.0)); // fine cloud streaks
  float bandA = 0.5 + 0.5*sin(lat*11.0 + 2.2*(n1 - 0.5));
  float bandB = 0.5 + 0.5*sin(lat*29.0 + 3.0*(n2 - 0.5) + 1.7);
  float band = 0.65*bandA + 0.35*bandB;
  vec3 surf = mix(NL_END_PLANET_COL2, NL_END_PLANET_COL1, band);
  surf = mix(surf, NL_END_PLANET_COL3, 0.25*smoothstep(0.6, 1.0, bandB));
  surf *= (0.88 + 0.24*n3)*(0.92 + 0.16*n4);

  // storms that rotate with the surface: bright cream oval and a dark spot
  vec3 np = vec3(uv.x, uv.y, lat);
  np = normalize(np); // outside the disc n is not a unit vector, which would overflow exp()
  float storm1 = exp(-(1.0 - dot(np, normalize(vec3(0.80, 0.30, -0.45))))*260.0);
  float storm2 = exp(-(1.0 - dot(np, normalize(vec3(-0.30, 0.90, 0.28))))*420.0);
  surf = mix(surf, NL_END_PLANET_COL3, 0.75*storm1);
  surf = mix(surf, NL_END_PLANET_COL2*0.55, 0.8*storm2);

  // polar hexagon
  float rho = sqrt(max(1.0 - lat*lat, 0.0));
  float ang = atan(uv.y, uv.x);
  float hex = rho*cos(mod(ang, 1.0472) - 0.5236);
  float hexMask = 1.0 - smoothstep(0.17, 0.22, hex);
  surf = mix(surf, NL_END_PLANET_POLAR_COL, 0.6*hexMask*smoothstep(0.78, 0.9, lat));

  // limb darkening and day/night
  float limb = 0.45 + 0.55*pow(zs, 0.6);
  float diff = smoothstep(-0.08, 0.6, lit);
  vec3 planet = surf*limb*(0.03 + 1.5*diff);

  // warm sunset band along the terminator
  float term = smoothstep(-0.05, 0.25, lit)*(1.0 - smoothstep(0.25, 0.6, lit));
  planet += surf*term*0.3*vec3(1.0, 0.45, 0.25);

  // ring shadow cast on the planet
  float ls = dot(axis, L);
  if (abs(ls) > 0.01) {
    float sh = -dot(axis, n)/ls;
    if (sh > 0.0) {
      vec3 hp = n + sh*L;
      planet *= 1.0 - 0.85*nlRingDensity(length(hp));
    }
  }

  // atmosphere on the lit limb
  float rim = 1.0 - zs;
  rim = rim*rim*rim;
  planet += NL_END_PLANET_ATMOS*NL_END_PLANET_GLOW*rim*(0.1 + 1.6*smoothstep(-0.2, 0.7, lit));
  planet += vec3(0.10, 0.15, 0.30)*rim*0.4*(1.0 - diff); // faint blue limb on the night side

  vec3 col = mix(sky, planet, disc);

  // thin atmosphere glow just outside the lit limb
  vec3 outDir = vec3(p.x, p.y, 0.0)/max(r, 0.001);
  float litLimb = smoothstep(-0.3, 0.6, dot(outDir, L));
  float halo = (1.0 - disc)*exp(-14.0*max(r - 1.0, 0.0))*litLimb;
  col += NL_END_PLANET_ATMOS*NL_END_PLANET_GLOW*halo;
  col += NL_END_PLANET_ATMOS*NL_END_PLANET_GLOW*0.06*(1.0 - disc)*exp(-3.0*max(r - 1.0, 0.0))*litLimb; // faint wide bloom

  // ---- ring (real 3D plane through the planet centre)
  #ifdef NL_END_PLANET_RING
    if (axis.z > 0.05) {
      float zr = -(axis.x*p.x + axis.y*p.y)/axis.z;
      vec3 hp = vec3(p.x, p.y, zr);
      float R = length(hp);
      float dens = nlRingDensity(R);
      bool behind = r2 < 1.0 && zr < zs;
      if (dens > 0.001 && !behind) {
        // planet shadow on the ring
        float sr = -dot(hp, L);
        float shadow = 1.0;
        if (sr > 0.0) {
          float d2 = dot(hp, hp) - dot(hp, L)*dot(hp, L);
          shadow = smoothstep(0.9, 1.08, d2);
        }
        float tone = 0.5 + 0.5*sin(R*31.0 + 2.0*noise2D(vec2(R*40.0, 1.0)));
        vec3 ringCol = mix(NL_END_PLANET_RING_COL*0.7, NL_END_PLANET_RING_COL*1.15, tone);
        ringCol *= (0.08 + 1.4*shadow);
        col = mix(col, ringCol, clamp(dens, 0.0, 1.0));
      }
    }
  #endif

  // ---- small moon
  #ifdef NL_END_PLANET_MOON
    vec2 md = p - vec2(-1.7, -0.85);
    float mr2 = dot(md, md)/(0.12*0.12);
    if (mr2 < 1.1) {
      float mz = sqrt(max(1.0 - mr2, 0.0));
      vec3 mn = vec3(md/0.12, mz);
      float mlit = smoothstep(-0.05, 0.55, dot(mn, L));
      float crater = noise2D(mn.xy*5.0 + 3.0);
      vec3 mcol = mix(vec3(0.62,0.52,0.45), vec3(0.85,0.76,0.66), crater)*(0.03 + 1.5*mlit)*(0.5 + 0.5*mz);
      col = mix(col, mcol, 1.0 - smoothstep(0.96, 1.0, sqrt(mr2)));
    }
  #endif

  return col;
}
#endif

vec3 nlRenderSky(nl_skycolor skycol, nl_environment env, vec3 viewDir, float t, bool isSkyPlane) {
  vec3 sky;
  viewDir.y = -viewDir.y;

  if (env.end) {
    sky = renderEndSky(skycol.horizon, skycol.zenith, viewDir, t);
  } else {
    sky = renderOverworldSky(skycol, env, viewDir, isSkyPlane);
    #ifdef NL_UNDERWATER_STREAKS
      // if (env.underwater) {
      //   float a = atan2(viewDir.x, viewDir.z);
      //   float grad = 0.5 + 0.5*viewDir.y;
      //   grad *= grad;
      //   float spread = (0.5 + 0.5*sin(3.0*a + 0.2*t + 2.0*sin(5.0*a - 0.4*t)));
      //   spread *= (0.5 + 0.5*sin(3.0*a - sin(0.5*t)))*grad;
      //   spread += (1.0-spread)*grad;
      //   float streaks = spread*spread;
      //   streaks *= streaks;
      //   streaks = (spread + 3.0*grad*grad + 4.0*streaks*streaks);
      //   sky += 2.0*streaks*skycol.horizon;
      // }
    #endif
  }

  return sky;
}

// shooting star
vec3 nlRenderShootingStar(vec3 viewDir, vec3 FOG_COLOR, float t) {
  // transition vars
  float h = t / (NL_SHOOTING_STAR_DELAY + NL_SHOOTING_STAR_PERIOD);
  float h0 = floor(h);
  t = (NL_SHOOTING_STAR_DELAY + NL_SHOOTING_STAR_PERIOD) * (h-h0);
  t = min(t/NL_SHOOTING_STAR_PERIOD, 1.0);
  float t0 = t*t;
  float t1 = 1.0-t0;
  t1 *= t1; t1 *= t1; t1 *= t1;

  // randomize size, rotation, add motion, add skew
  float r = fract(sin(h0) * 43758.545313);
  float a = 6.2831*r;
  float cosa = cos(a);
  float sina = sin(a);
  vec2 uv = viewDir.xz * (6.0 + 4.0*r);
  uv = vec2(cosa*uv.x + sina*uv.y, -sina*uv.x + cosa*uv.y);
  uv.x += t1 - t;
  uv.x -= 2.0*r + 3.5;
  uv.y += viewDir.y * 3.0;

  // draw star
  float g = 1.0-min(abs((uv.x-0.95))*20.0, 1.0); // source glow
  float s = 1.0-min(abs(8.0*uv.y), 1.0); // line
  s *= s*s*smoothstep(-1.0+1.96*t1, 0.98-t, uv.x); // decay tail
  s *= s*s*smoothstep(1.0, 0.98-t0, uv.x); // decay source
  s *= 1.0-t1; // fade in
  s *= 1.0-t0; // fade out
  s *= 0.7 + 16.0*g*g;
  s *= max(1.0-FOG_COLOR.r-FOG_COLOR.g-FOG_COLOR.b, 0.0); // fade out during day
  return s*vec3(0.8, 0.9, 1.0);
}

// Galaxy stars - needs further optimization
vec3 nlRenderGalaxy(vec3 vdir, vec3 fogColor, nl_environment env, float t) {
  if (env.underwater) {
    return vec3_splat(0.0);
  }

  t *= NL_GALAXY_SPEED;

  // rotate space
  float cosb = sin(0.2*t);
  float sinb = cos(0.2*t);
  vdir.xy = mul(mat2(cosb, sinb, -sinb, cosb), vdir.xy);

  // noise
  float n0 = 0.5 + 0.5*sin(5.0*vdir.x)*sin(5.0*vdir.y - 0.5*t)*sin(5.0*vdir.z + 0.5*t);
  float n1 = noise3D(15.0*vdir + sin(0.85*t + 1.3));
  float n2 = noise3D(50.0*vdir + 1.0*n1 + sin(0.7*t + 1.0));
  float n3 = noise3D(200.0*vdir - 10.0*sin(0.4*t + 0.500));

  // stars
  n3 = smoothstep(0.04,0.3,n3+0.02*n2);
  float gd = vdir.x + 0.1*vdir.y + 0.1*sin(10.0*vdir.z + 0.2*t);
  float st = n1*n2*n3*n3*(1.0+70.0*gd*gd);
  st = (1.0-st)/(1.0+400.0*st);
  vec3 stars = (0.8 + 0.2*sin(vec3(8.0,6.0,10.0)*(2.0*n1+0.8*n2) + vec3(0.0,0.4,0.82)))*st;

  // glow
  float gfmask = abs(vdir.x)-0.15*n1+0.04*n2+0.25*n0;
  float gf = 1.0 - (vdir.x*vdir.x + 0.03*n1 + 0.2*n0);
  gf *= gf;
  gf *= gf*gf;
  gf *= 1.0-0.3*smoothstep(0.2, 0.3, gfmask);
  gf *= 1.0-0.2*smoothstep(0.3, 0.4, gfmask);
  gf *= 1.0-0.1*smoothstep(0.2, 0.1, gfmask);
  vec3 gfcol = normalize(vec3(n0, cos(2.0*vdir.y), sin(vdir.x+n0)));
  stars += (0.4*gf + 0.012)*mix(vec3(0.5, 0.5, 0.5), gfcol*gfcol, NL_GALAXY_VIBRANCE);

  stars *= mix(1.0, NL_GALAXY_DAY_VISIBILITY, env.dayFactor);

  return stars*(1.0-env.rainFactor);
}


#endif
